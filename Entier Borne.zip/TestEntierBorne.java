import java.util.Scanner;


public class TestEntierBorne {
    public static void main(String[] args) throws InterruptedException,HorsBorneException, ArithmeticException {
        Scanner clavier = new Scanner(System.in);

        /***
         * Try catch des sommes de bibi
         */
        try {
            System.out.println("Entre un premier chiffre bibi : ");
            int premierInput = Integer.valueOf(clavier.nextLine());
            EntierBorne premierChiffre =  new EntierBorne(premierInput);

            System.out.println("Entre un deuxieme chiffre omri : ");
            int deuxiemeInput = Integer.valueOf(clavier.nextLine());
            EntierBorne deuxiemeChiffre = new EntierBorne(deuxiemeInput);

            System.out.println("Tiens la somme des  2 entiers choupi: " + premierChiffre.somme(deuxiemeChiffre));

        } catch (NumberFormatException exception) {
            Thread.sleep(1000);
            System.out.println("Problematique tout ca bibi : un des deux ou les deux ne sont pas un entier" + exception);
        } catch (HorsBorneException horsBorneException) {
            System.out.println("ouais nan trop grand ton chiffre chico" + horsBorneException);
        }

        /***
         * Try catch des divisions de bibi
         */

        try {
            System.out.println("Donne moi le chiffre que tu veux diviser coco: ");
            int chiffreDiviser = Integer.valueOf(clavier.nextLine());
            EntierBorne chiffreADiviser = new EntierBorne(chiffreDiviser);

            System.out.println("Donne moi le chiffre qui va diviser ");
            int chiffreDivisible = Integer.valueOf(clavier.nextLine());
            EntierBorne chiffreQuiDivisera = new EntierBorne(chiffreDivisible);

            System.out.println("TROP BO CETTE DIVISION: " + chiffreADiviser.divPar(chiffreQuiDivisera));

        } catch (HorsBorneException hb){
                System.out.println("Chiffre too big or too petit pepito" + hb);
            } catch (ArithmeticException as){
                System.out.println("Retour à l'école : pas de divison par 0" + as);
            }

        /***
         * Try catch des factorielle de bibi
         */

        try {
            System.out.println("DONNE TON CHIFFRE POUR QUE JE LUI FASSE DES DINGUERIES DE MALADE");
            int fact = Integer.valueOf(clavier.nextLine());
            EntierBorne factorielle = new EntierBorne(fact);

            System.out.println("Tiens ce chiffre magique boubou: " + factorielle.factorielle());
        } catch(IllegalArgumentException negatif){
            System.out.println("on t'a dit que tu peux pas diviser par 0 frerot" + negatif);
        } catch (HorsBorneException hb){
            System.out.println("ton chiffre qui fait 345546454 ou -243544343 là, flemme trop grand." + hb);
        }

    }
}


