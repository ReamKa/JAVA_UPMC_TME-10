public class EntierBorne {
    private int nombre;

    /***
     * Constructeur d'EntierBorne
     * @param nombre
     * @throws HorsBorneException
     */
    public EntierBorne(int nombre) throws HorsBorneException {
        this.nombre = nombre;
        if (nombre < -10000 || nombre > 10000) {
            throw new HorsBorneException("Chiffre soit plus petit que -10 000 ou plus grand que 10 000");
        }
    }

    public String toString() {
        return "Entier = " + nombre;
    }

    /***
     * Calcul de la somme
     * @param i
     * @return la somme de l'objet courant avec l'objet passé en parametre
     * @throws HorsBorneException
     */
    public EntierBorne somme(EntierBorne i) throws HorsBorneException {
        if (i.nombre + this.nombre > 10000) {
            throw new HorsBorneException("trop grand tout ca mon grand");
        }
        return new EntierBorne(i.nombre + this.nombre);
    }

    /***
     * Calcul de division
     * @param i
     * @return la division de l'objet courant par l'objet passé en paramètre
     * @throws ArithmeticException
     * @throws HorsBorneException
     */
    public EntierBorne divPar(EntierBorne i) throws ArithmeticException, HorsBorneException {
        if (i.nombre == 0) {
            throw new ArithmeticException("Division par 0");
        } else if (this.nombre / i.nombre < -10000 || this.nombre / i.nombre > 10000) {
            throw new HorsBorneException("Division trop petite ou trop grande et Dieu sait mieux");
        } else return new EntierBorne(this.nombre / i.nombre);
    }

    /***
     * Calcul factoriel
     * @return la factorielle de l'element de EntierBorne courant
     * @throws IllegalArgumentException
     * @throws HorsBorneException
     */
    public EntierBorne factorielle() throws IllegalArgumentException, HorsBorneException {
        int total = 1;
        if (this.nombre < 0) {
            throw new IllegalArgumentException();
        } else {
            for (int i = 1; i <= this.nombre; i++) {
                total *= i;

                if(total > 10000 || total < -10000) {
                    throw new HorsBorneException("trop grand chiffre ou petit chiffre");
                }
            }
        }
        return new EntierBorne(total);
    }
}
