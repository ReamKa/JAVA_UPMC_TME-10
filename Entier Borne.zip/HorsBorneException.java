public class HorsBorneException extends Exception {
    public HorsBorneException(String s){
        super(s);
    }
    public String toString(){
        return "Hors Borne Exception est levee";
    }
}
